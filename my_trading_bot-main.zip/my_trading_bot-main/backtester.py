import yfinance as yf
import pandas as pd

class Backtester:
    def __init__(self, symbol, trader, start_date='2020-01-01', end_date=None):
        self.symbol = symbol
        self.trader = trader
        self.start_date = start_date
        self.end_date = end_date

    def _load_data(self):
        df = yf.download(
            self.symbol,
            start=self.start_date,
            end=self.end_date,
            progress=False,
            auto_adjust=True
        )
        # אם התקבל DataFrame עם MultiIndex בעמודות, נדאג לקבל את השמות של ה־attributes
        if isinstance(df.columns, pd.MultiIndex):
            # level 0: attributes, level 1: tickers
            # אם ברשימת ה־attributes יש Close, נוריד את הרמה השנייה
            if 'Close' in df.columns.get_level_values(0):
                df.columns = df.columns.get_level_values(0)
            # אחרת אולי ההפך, נבדוק level 1
            elif 'Close' in df.columns.get_level_values(1):
                df.columns = df.columns.get_level_values(1)
        # לבסוף נוודא שיש בעמודות Close
        if 'Close' not in df.columns:
            raise KeyError(f"לא נמצאה עמודת Close ב־DataFrame, העמודות הן: {list(df.columns)}")
        # נחזיר רק את הסגירה
        return df[['Close']]

    def run_backtest(self):
        data = self._load_data()
        self.trader.run(self.symbol, data)
