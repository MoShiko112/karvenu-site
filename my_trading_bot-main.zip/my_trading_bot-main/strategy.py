import talib

def generate_signal(df):
    close = df['Close']
    sma = talib.SMA(close, timeperiod=20)
    rsi = talib.RSI(close, timeperiod=14)
    macd, macdsignal, _ = talib.MACD(close, fastperiod=12, slowperiod=26, signalperiod=9)

    latest_close = close.iloc[-1]
    latest_sma = sma.iloc[-1]
    latest_rsi = rsi.iloc[-1]
    latest_macd = macd.iloc[-1]
    latest_macdsignal = macdsignal.iloc[-1]

    if latest_close > latest_sma and latest_rsi < 70 and latest_macd > latest_macdsignal:
        return 'BUY'
    elif latest_close < latest_sma and latest_rsi > 30 and latest_macd < latest_macdsignal:
        return 'SELL'
    else:
        return 'HOLD'
