# My Trading Bot - Stage 2

Includes simple moving average strategy and backtesting.

## How to run

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the bot:
   ```
   python src/main.py
   ```

## What it does

Loads stock data, applies a simple MA strategy, runs a backtest, saves results.
