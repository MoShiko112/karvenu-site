class Portfolio:
    def __init__(self, initial_balance):
        self.initial_balance = float(initial_balance)
        self.cash = float(initial_balance)
        self.holdings = {}
        self.trade_history = []

    def buy(self, symbol, price, quantity):
        cost = price * quantity
        if self.cash < cost:
            raise ValueError("Insufficient cash")
        self.cash -= cost
        self.holdings[symbol] = self.holdings.get(symbol, 0) + quantity
        self.trade_history.append({
            'action': 'BUY',
            'symbol': symbol,
            'price': price,
            'quantity': quantity
        })

    def sell(self, symbol, price, quantity):
        if self.holdings.get(symbol, 0) < quantity:
            raise ValueError("Insufficient holdings")
        self.holdings[symbol] -= quantity
        proceeds = price * quantity
        self.cash += proceeds
        self.trade_history.append({
            'action': 'SELL',
            'symbol': symbol,
            'price': price,
            'quantity': quantity
        })
