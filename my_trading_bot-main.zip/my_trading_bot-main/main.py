from backtester import Backtester
from trader import Trader

def main():
    initial_balance = 10000  # תחליף לפי דרישה
    trader = Trader(initial_balance)
    bt = Backtester("AAPL", trader, start_date="2020-01-01")
    bt.run_backtest()

if __name__ == "__main__":
    main()
