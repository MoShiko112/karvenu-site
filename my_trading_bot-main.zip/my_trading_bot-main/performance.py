import numpy as np

def calc_equity_curve(history):
    """
    history: list of (date, equity)
    מחזיר תאריכים, ערך הון ו־returns יומיים
    """
    dates, eq = zip(*history)
    returns = np.diff(eq) / eq[:-1]
    return dates, eq, returns

def sharpe_ratio(returns, rf=0.0):
    """
    ממוצע תשואה חלקי סטיית תקן
    """
    return (np.mean(returns) - rf) / np.std(returns) if len(returns) > 1 else 0.0

def summary_stats(history):
    """
    מחזיר dict עם אחוז תשואה כולל, Sharpe ו-מספר טריידים
    """
    _, _, returns = calc_equity_curve(history)
    total_return = (history[-1][1] / history[0][1] - 1) * 100
    return {
        'total_return_pct': total_return,
        'sharpe': sharpe_ratio(returns),
        'trades': len(history) - 1
    }
