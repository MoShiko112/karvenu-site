import csv

class Logger:
    def __init__(self, filename):
        self.filename = filename
        with open(self.filename, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['action', 'symbol', 'price', 'quantity'])

    def log_trade(self, trade):
        with open(self.filename, mode='a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([trade['action'], trade['symbol'], trade['price'], trade['quantity']])