import yfinance as yf

def load_data(ticker):
    data = yf.download(ticker, period="3mo", interval="1d")
    print(data.head())
    return data
