import pandas as pd
from sklearn.ensemble import RandomForestClassifier

class Model:
    def __init__(self):
        self.model = RandomForestClassifier(n_estimators=100, random_state=42)
        self.is_trained = False

    def add_features(self, df):
        df = df.copy()
        df['SMA_20'] = df['Close'].rolling(window=20).mean()
        df['SMA_50'] = df['Close'].rolling(window=50).mean()
        return df

    def prepare_data(self, data):
        df = self.add_features(data)
        df = df.dropna()
        # X עד השורה שלפני האחרונה, y = האם המניה תעלה ביום הבא
        X = df[['SMA_20', 'SMA_50']].iloc[:-1]
        y = (df['Close'].shift(-1) > df['Close']).astype(int).iloc[:-1]
        return X, y

    def train(self, data):
        X, y = self.prepare_data(data)
        self.model.fit(X, y)
        self.is_trained = True

    def predict(self, data):
        X, _ = self.prepare_data(data)
        preds = self.model.predict(X)
        # מחזיר סדרת pandas עם האינדקס המקורי
        return pd.Series(preds, index=X.index)
