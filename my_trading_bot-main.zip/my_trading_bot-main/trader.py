import pandas as pd
from portfolio import Portfolio
from model import Model

class Trader:
    def __init__(self, initial_balance):
        self.portfolio = Portfolio(initial_balance)
        self.model = Model()

    def run(self, symbol, data):
        # מאמן בפעם הראשונה
        if not self.model.is_trained:
            self.model.train(data)

        # מחשב אותות buy/sell
        signals = self.model.predict(data)
        df = data.loc[signals.index].copy()
        df['Signal'] = signals.map({1: 'BUY', 0: 'SELL'})

        # רץ על כל השורות
        qty = 5
        for idx, row in df.iterrows():
            price = row['Close']

            if row['Signal'] == 'BUY':
                # קנייה רק אם יש מספיק מזומן
                cost = price * qty
                if self.portfolio.cash >= cost:
                    self.portfolio.buy(symbol, price, qty)
                    print(f"BUY  {symbol} at {price}")
                else:
                    print(f"SKIP BUY  {symbol} at {price} (no cash)")

            else:  # SELL
                # נמכור רק אם יש מספיק שבהחזקות
                available = self.portfolio.holdings.get(symbol, 0)
                if available >= qty:
                    self.portfolio.sell(symbol, price, qty)
                    print(f"SELL {symbol} at {price}")
                else:
                    print(f"SKIP SELL {symbol} at {price} (no holdings)")

        # בסיום – מציג ביצועים וסיכום תיק
        last_price = data['Close'].iloc[-1]
        total_value = self.portfolio.cash + sum(q * last_price for q in self.portfolio.holdings.values())
        total_return = (total_value - self.portfolio.initial_balance) / self.portfolio.initial_balance * 100

        print("Performance Stats:", {
            'total_return_pct': total_return,
            'trades': len(self.portfolio.trade_history)
        })
        print("Portfolio Summary:", {
            'cash': self.portfolio.cash,
            'holdings': self.portfolio.holdings,
            'trade_history': self.portfolio.trade_history
        })
